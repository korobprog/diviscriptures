#!/usr/bin/env python3
"""
Test script for Srimad Bhagavatam parsing with database verification
"""
import asyncio
from srimad_bhagavatam_parser_v2 import SrimadBhagavatamParser
from database import DatabaseManager

async def test_parse_and_verify():
    """Parse SB chapter and verify it's saved to database"""
    print("🔍 Testing Srimad Bhagavatam parsing with database verification...")
    
    try:
        parser = SrimadBhagavatamParser()
        
        async with DatabaseManager() as db:
            # Get initial count
            initial_count = await db.get_verse_count('sb')
            print(f"📊 Initial SB verses in database: {initial_count}")
            
            async with parser:
                # Parse chapter 1.1
                print("\n📚 Parsing SB 1.1...")
                verses = await parser.parse_chapter(1, 1)
                print(f"✅ Parsed {len(verses)} verses from SB 1.1")
                
                if verses:
                    # Show first verse details
                    first_verse = verses[0]
                    print(f"\n📖 First verse details:")
                    print(f"   Canto: {first_verse.canto}")
                    print(f"   Chapter: {first_verse.chapter}")
                    print(f"   Verse: {first_verse.verse_number}")
                    print(f"   Sanskrit: {first_verse.sanskrit[:50]}...")
                    print(f"   Translation: {first_verse.translation[:50]}...")
                    print(f"   Transliteration: {first_verse.transliteration[:50] if first_verse.transliteration else 'None'}...")
                    
                    # Save to database
                    print(f"\n💾 Saving verses to database...")
                    saved_count = await db.save_verses(verses)
                    print(f"✅ Saved {saved_count} verses to database")
                    
                    # Verify in database
                    print(f"\n🔍 Verifying verses in database...")
                    final_count = await db.get_verse_count('sb')
                    print(f"📊 Final SB verses in database: {final_count}")
                    
                    # Check specific verses
                    db_verses = await db.get_verses_by_chapter('Шримад-Бхагаватам', 1, 5)
                    print(f"📋 Found {len(db_verses)} verses in database for SB 1.1")
                    
                    # Verify first verse
                    if db_verses:
                        db_first_verse = db_verses[0]
                        print(f"\n✅ Verification of first verse:")
                        print(f"   Database ID: {db_first_verse['id']}")
                        print(f"   Chapter: {db_first_verse['chapter']}")
                        print(f"   Verse: {db_first_verse['verseNumber']}")
                        print(f"   Sanskrit matches: {first_verse.sanskrit[:30] == db_first_verse['sanskrit'][:30]}")
                        print(f"   Translation matches: {first_verse.translation[:30] == db_first_verse['translation'][:30]}")
                        
                        # Check all fields
                        fields_to_check = [
                            ('sanskrit', 'Sanskrit'),
                            ('translation', 'Translation'),
                            ('transliteration', 'Transliteration'),
                            ('wordByWordTranslation', 'Word-by-word')
                        ]
                        
                        print(f"\n📝 Field verification:")
                        for field, name in fields_to_check:
                            original_value = getattr(first_verse, field.replace('ByWord', '_by_word'), None)
                            db_value = db_first_verse.get(field)
                            
                            if original_value and db_value:
                                matches = original_value[:50] == db_value[:50]
                                status = "✅" if matches else "❌"
                                print(f"   {status} {name}: {'Match' if matches else 'Mismatch'}")
                            elif original_value:
                                print(f"   ❌ {name}: Missing in database")
                            elif db_value:
                                print(f"   ⚠️  {name}: Extra in database")
                            else:
                                print(f"   ➖ {name}: Both empty")
                    
                    # Show quality statistics
                    print(f"\n📊 Quality statistics:")
                    verses_with_sanskrit = sum(1 for v in verses if v.sanskrit and len(v.sanskrit.strip()) > 10)
                    verses_with_translation = sum(1 for v in verses if v.translation and len(v.translation.strip()) > 20)
                    verses_with_transliteration = sum(1 for v in verses if v.transliteration and len(v.transliteration.strip()) > 20)
                    verses_with_word_by_word = sum(1 for v in verses if v.word_by_word_translation and len(v.word_by_word_translation.strip()) > 20)
                    
                    print(f"   Total verses: {len(verses)}")
                    print(f"   With Sanskrit: {verses_with_sanskrit} ({verses_with_sanskrit/len(verses)*100:.1f}%)")
                    print(f"   With translation: {verses_with_translation} ({verses_with_translation/len(verses)*100:.1f}%)")
                    print(f"   With transliteration: {verses_with_transliteration} ({verses_with_transliteration/len(verses)*100:.1f}%)")
                    print(f"   With word-by-word: {verses_with_word_by_word} ({verses_with_word_by_word/len(verses)*100:.1f}%)")
                    
                    # Final verification
                    if final_count > initial_count:
                        print(f"\n🎉 SUCCESS: {final_count - initial_count} new verses added to database!")
                    else:
                        print(f"\n⚠️  WARNING: No new verses added to database")
                    
                    return True
                else:
                    print("❌ No verses parsed")
                    return False
                    
    except Exception as e:
        print(f"❌ Error during parsing: {e}")
        return False

async def main():
    """Main function"""
    success = await test_parse_and_verify()
    
    if success:
        print(f"\n✅ Test completed successfully!")
    else:
        print(f"\n❌ Test failed!")
        exit(1)

if __name__ == "__main__":
    asyncio.run(main())