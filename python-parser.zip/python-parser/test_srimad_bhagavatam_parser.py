#!/usr/bin/env python3
"""
Test script for Srimad Bhagavatam parser
"""
import asyncio
import sys
import os
import json
from pathlib import Path

# Add the parser directory to the Python path
sys.path.append(str(Path(__file__).parent))

from srimad_bhagavatam_parser_v2 import SrimadBhagavatamParser
from config import PARSER_CONFIG


async def test_parse_single_chapter():
    """Test parsing a single chapter of Srimad Bhagavatam"""
    print("🧪 Testing Srimad Bhagavatam Parser")
    print("=" * 50)
    
    # Test configuration
    config = {
        **PARSER_CONFIG,
        'max_concurrency': 1,  # Single request for testing
        'delay_between_requests': 1.0,  # Shorter delay for testing
    }
    
    async with SrimadBhagavatamParser(config) as parser:
        # Test parsing Canto 1, Chapter 1 (first chapter)
        canto = 1
        chapter = 1
        
        print(f"📖 Parsing SB {canto}.{chapter}...")
        
        try:
            verses = await parser.parse_chapter(canto, chapter)
            
            if verses:
                print(f"✅ Successfully parsed {len(verses)} verses")
                
                # Display first few verses
                for i, verse in enumerate(verses[:3]):
                    print(f"\n📝 Verse {verse.canto}.{verse.chapter}.{verse.verse_number}:")
                    print(f"   Sanskrit: {verse.sanskrit[:100]}{'...' if len(verse.sanskrit) > 100 else ''}")
                    print(f"   Transliteration: {verse.transliteration[:100] if verse.transliteration else 'N/A'}{'...' if verse.transliteration and len(verse.transliteration) > 100 else ''}")
                    print(f"   Translation: {verse.translation[:100]}{'...' if len(verse.translation) > 100 else ''}")
                    print(f"   Commentary: {verse.commentary[:100] if verse.commentary else 'N/A'}{'...' if verse.commentary and len(verse.commentary) > 100 else ''}")
                
                if len(verses) > 3:
                    print(f"\n... and {len(verses) - 3} more verses")
                
                # Save results to file
                output_file = f"test_sb_{canto}_{chapter}_results.json"
                with open(output_file, 'w', encoding='utf-8') as f:
                    json.dump([verse.dict() for verse in verses], f, ensure_ascii=False, indent=2)
                print(f"\n💾 Results saved to {output_file}")
                
                return True
            else:
                print("❌ No verses found")
                return False
                
        except Exception as e:
            print(f"❌ Error parsing chapter: {e}")
            return False


async def test_parse_multiple_chapters():
    """Test parsing multiple chapters"""
    print("\n🧪 Testing Multiple Chapters")
    print("=" * 50)
    
    config = {
        **PARSER_CONFIG,
        'max_concurrency': 2,
        'delay_between_requests': 2.0,
    }
    
    async with SrimadBhagavatamParser(config) as parser:
        test_chapters = [
            (1, 1),  # Canto 1, Chapter 1
            (1, 2),  # Canto 1, Chapter 2
            (2, 1),  # Canto 2, Chapter 1
        ]
        
        all_verses = []
        success_count = 0
        
        for canto, chapter in test_chapters:
            print(f"📖 Parsing SB {canto}.{chapter}...")
            
            try:
                verses = await parser.parse_chapter(canto, chapter)
                
                if verses:
                    print(f"✅ {len(verses)} verses parsed")
                    all_verses.extend(verses)
                    success_count += 1
                else:
                    print("❌ No verses found")
                    
            except Exception as e:
                print(f"❌ Error: {e}")
        
        print(f"\n📊 Summary:")
        print(f"   Chapters parsed: {success_count}/{len(test_chapters)}")
        print(f"   Total verses: {len(all_verses)}")
        
        if all_verses:
            # Save all results
            output_file = "test_sb_multiple_chapters_results.json"
            with open(output_file, 'w', encoding='utf-8') as f:
                json.dump([verse.dict() for verse in all_verses], f, ensure_ascii=False, indent=2)
            print(f"💾 All results saved to {output_file}")
        
        return success_count > 0


async def test_parser_quality():
    """Test parser quality and validation"""
    print("\n🧪 Testing Parser Quality")
    print("=" * 50)
    
    config = {
        **PARSER_CONFIG,
        'max_concurrency': 1,
        'delay_between_requests': 1.0,
    }
    
    async with SrimadBhagavatamParser(config) as parser:
        canto = 1
        chapter = 1
        
        try:
            verses = await parser.parse_chapter(canto, chapter)
            
            if not verses:
                print("❌ No verses to analyze")
                return False
            
            # Analyze quality
            total_verses = len(verses)
            verses_with_sanskrit = sum(1 for v in verses if v.sanskrit and len(v.sanskrit.strip()) > 10)
            verses_with_translation = sum(1 for v in verses if v.translation and len(v.translation.strip()) > 20)
            verses_with_transliteration = sum(1 for v in verses if v.transliteration and len(v.transliteration.strip()) > 20)
            verses_with_word_by_word = sum(1 for v in verses if v.word_by_word_translation and len(v.word_by_word_translation.strip()) > 20)
            verses_with_commentary = sum(1 for v in verses if v.commentary and len(v.commentary.strip()) > 20)
            
            print(f"📊 Quality Analysis for SB {canto}.{chapter}:")
            print(f"   Total verses: {total_verses}")
            print(f"   With Sanskrit: {verses_with_sanskrit} ({verses_with_sanskrit/total_verses*100:.1f}%)")
            print(f"   With translation: {verses_with_translation} ({verses_with_translation/total_verses*100:.1f}%)")
            print(f"   With transliteration: {verses_with_transliteration} ({verses_with_transliteration/total_verses*100:.1f}%)")
            print(f"   With word-by-word: {verses_with_word_by_word} ({verses_with_word_by_word/total_verses*100:.1f}%)")
            print(f"   With commentary: {verses_with_commentary} ({verses_with_commentary/total_verses*100:.1f}%)")
            
            # Check for quality issues
            quality_issues = []
            for verse in verses:
                if not verse.sanskrit or len(verse.sanskrit.strip()) <= 10:
                    quality_issues.append(f"Verse {verse.verse_number}: Missing or short Sanskrit")
                if not verse.translation or len(verse.translation.strip()) <= 20:
                    quality_issues.append(f"Verse {verse.verse_number}: Missing or short translation")
            
            if quality_issues:
                print(f"\n⚠️  Quality Issues Found:")
                for issue in quality_issues[:5]:  # Show first 5 issues
                    print(f"   - {issue}")
                if len(quality_issues) > 5:
                    print(f"   ... and {len(quality_issues) - 5} more issues")
            else:
                print("\n✅ No major quality issues found")
            
            return verses_with_sanskrit > 0 and verses_with_translation > 0
            
        except Exception as e:
            print(f"❌ Error in quality test: {e}")
            return False


async def main():
    """Main test function"""
    print("🚀 Starting Srimad Bhagavatam Parser Tests")
    print("=" * 60)
    
    tests = [
        ("Single Chapter", test_parse_single_chapter),
        ("Multiple Chapters", test_parse_multiple_chapters),
        ("Parser Quality", test_parser_quality),
    ]
    
    results = []
    
    for test_name, test_func in tests:
        print(f"\n🧪 Running test: {test_name}")
        try:
            result = await test_func()
            results.append((test_name, result))
            print(f"{'✅' if result else '❌'} Test {test_name}: {'PASSED' if result else 'FAILED'}")
        except Exception as e:
            print(f"❌ Test {test_name}: ERROR - {e}")
            results.append((test_name, False))
    
    # Summary
    print("\n" + "=" * 60)
    print("📊 TEST SUMMARY")
    print("=" * 60)
    
    passed = sum(1 for _, result in results if result)
    total = len(results)
    
    for test_name, result in results:
        status = "✅ PASSED" if result else "❌ FAILED"
        print(f"   {test_name}: {status}")
    
    print(f"\nOverall: {passed}/{total} tests passed")
    
    if passed == total:
        print("🎉 All tests passed! Parser is working correctly.")
    else:
        print("⚠️  Some tests failed. Check the output above for details.")
    
    return passed == total


if __name__ == "__main__":
    # Run the tests
    success = asyncio.run(main())
    sys.exit(0 if success else 1)
